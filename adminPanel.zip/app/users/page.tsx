// app/about.tsx
import React from 'react';
import DataTable from '../components/datatables';
import Home from '../page';  // Ensure to update this import as well

const users = () => {
  const data = [
    { id: 1, name: 'John Doe', age: 28, email: 'john@example.com', role: 'Admin' },
    { id: 2, name: 'Jane Smith', age: 34, email: 'jane@example.com', role: 'User' },
    { id: 3, name: 'Alice Johnson', age: 25, email: 'alice@example.com', role: 'Editor' },
    { id: 4, name: 'Bob Brown', age: 45, email: 'bob@example.com', role: 'Admin' },
    { id: 5, name: 'Charlie Blue', age: 22, email: 'charlie@example.com', role: 'Viewer' },
    { id: 6, name: 'Diana Green', age: 30, email: 'diana@example.com', role: 'Editor' },
    { id: 7, name: 'Eva White', age: 29, email: 'eva@example.com', role: 'User' },
    { id: 8, name: 'Frank Black', age: 33, email: 'frank@example.com', role: 'Viewer' },
    { id: 9, name: 'Grace Stone', age: 27, email: 'grace@example.com', role: 'Admin' },
    { id: 10, name: 'Hank Marvel', age: 36, email: 'hank@example.com', role: 'User' },
    { id: 11, name: 'Ivy Lane', age: 31, email: 'ivy@example.com', role: 'Editor' },
    { id: 12, name: 'Jack Frost', age: 24, email: 'jack@example.com', role: 'Admin' },
    { id: 13, name: 'Kara Blane', age: 26, email: 'kara@example.com', role: 'User' },
    { id: 14, name: 'Leo King', age: 29, email: 'leo@example.com', role: 'Viewer' },
    { id: 15, name: 'Mona Duke', age: 41, email: 'mona@example.com', role: 'Admin' },
    { id: 16, name: 'Nate Bane', age: 35, email: 'nate@example.com', role: 'Editor' },
    { id: 17, name: 'Olive Park', age: 30, email: 'olive@example.com', role: 'User' },
    { id: 18, name: 'Paul Reed', age: 37, email: 'paul@example.com', role: 'Viewer' },
    { id: 19, name: 'Quinn Hale', age: 28, email: 'quinn@example.com', role: 'Admin' },
    { id: 20, name: 'Rita Gold', age: 32, email: 'rita@example.com', role: 'User' },
    { id: 21, name: 'Sam Vale', age: 25, email: 'sam@example.com', role: 'Editor' },
    { id: 22, name: 'Tina Fay', age: 33, email: 'tina@example.com', role: 'Viewer' },
    { id: 23, name: 'Uma Black', age: 38, email: 'uma@example.com', role: 'Admin' },
    { id: 24, name: 'Vic Dean', age: 29, email: 'vic@example.com', role: 'User' },
    { id: 25, name: 'Will Doe', age: 40, email: 'will@example.com', role: 'Editor' }
];

const columns = [
    { Header: 'ID', accessor: 'id' },
    { Header: 'Name', accessor: 'name' },
    { Header: 'Age', accessor: 'age' },
    { Header: 'Email', accessor: 'email' },
    { Header: 'Role', accessor: 'role' }
];


  return (
    <Home>
      <div className="p-4">
        <h1 className="text-2xl font-bold mb-4">Data Table Example</h1>
        <DataTable data={data} columns={columns} />
      </div>
    </Home>
  );
};

export default users;
