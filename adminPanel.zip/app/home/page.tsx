
import Home from '../page';
const HomePage = () => {
    return (

      <Home>
      <h1 className="text-2xl font-bold">HOME PAGE</h1>
      </Home>
    );
  };
  
  export default HomePage;
  