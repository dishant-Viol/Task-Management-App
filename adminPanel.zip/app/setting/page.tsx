
import Home from '../page';
const SettingPage = () => {
    return (

      <Home>
      <h1 className="text-2xl font-bold">Setting Page</h1>
      </Home>
    );
  };
  
  export default SettingPage;
  