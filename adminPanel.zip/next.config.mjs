/** @type {import('next').NextConfig} */
const nextConfig = {
    // The App Router is now enabled by default in Next.js 13+
    // No need to specify it in the experimental options
  }
  
  export default nextConfig;